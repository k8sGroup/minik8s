ID=`ps -ef | grep prometheus | grep -v "grep" | awk '{print $2}'`
echo $ID
echo "killing prometheus..."
kill -9 $ID
echo "prometheus killed, pid: $ID."

