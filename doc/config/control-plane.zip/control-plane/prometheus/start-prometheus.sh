nohup $PROMETHEUS_HOME/prometheus --config.file=$PROMETHEUS_HOME/prometheus.yml > $PROMETHEUS_HOME/prometheus.log 2>&1 &
