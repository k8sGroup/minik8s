#!/bin/sh
V2=`ps -ef | grep etcdv2 | grep -v "grep" | awk '{print $2}'`
echo $V2
echo "killing etcdv2..."
kill -9 $V2
echo "etcdv2 killed, pid: $V2."

echo ""

V3=`ps -ef | grep etcdv3 | grep -v "grep" | awk '{print $2}'`
echo $V3
echo "killing etcdv3..."
kill -9 $V3
echo "etcdv3 killed, pid: $V3."

