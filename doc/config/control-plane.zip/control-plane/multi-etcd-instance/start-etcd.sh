nohup $ETCD_HOME/etcd-v3/etcdv3 --config-file=$ETCD_HOME/etcd-v3/config.yaml > $ETCD_HOME/etcd-v3/etcdv3.log 2>&1 &
nohup $ETCD_HOME/etcd-v2/etcdv2 --config-file=$ETCD_HOME/etcd-v2/config.yaml > $ETCD_HOME/etcd-v2/etcdv2.log 2>&1 &
